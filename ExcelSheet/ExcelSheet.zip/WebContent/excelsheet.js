$(function() {
	excel.init();
});

var excel = (function(){
	var inpt = $('<input type="text" value=""/>');
	var saveAndExit = function(){
		var val = $(this).attr('value');
		$(this).parent().text(val);
		$(this).remove();
	};
	var enableEditing = function(event){
		if($(this).find('input').length<1){
			var inpt1 = inpt.clone();
			inpt1.attr('value',$(this).text());
			$(this).html(inpt1);
			inpt1.focus();
			inpt1.width($(this).width()-2);
			$(inpt1).focusout(saveAndExit);
			inpt1.keyup(function(e){
				if(e.keyCode=='13'){
					saveAndExit.call(inpt1);
				}
			});
		}
		$('td').removeClass('selected');
		$(this).addClass('selected');
	};
	var initFormattingButtons = function(){
		$('#bold').on('click',function(){
			$('.selected').toggleClass('bold');
		});
		$('#italic').on('click',function(){
			$('.selected').toggleClass('italic');
		});
		$('#underline').on('click',function(){
			$('.selected').toggleClass('underline');
		});
	};
	var initTableEditing = function(){
		$('#addRows').on('click', function(){
			alert("Not yet implemented");
		});
		$('#addColumns').on('click', function(){
			alert("Not yet implemented");			
		});
		$('#removeRows').on('click', function(){
			var number = prompt("Enter the number of row to be removed");
			var removed = false;
			$('td:first-child').each(function(i, el){
				if(i>0){
					if(number==$(el).text()){
						$(el).parent().remove();
						removed =true;
					}
					if(removed){
						$(el).text(i);
					}
				}
			});
		});
		$('#removeColumns').on('click', function(){
			alert("Not yet implemented");
		});
	};
	return{
		init:function(){
			$('td').data('formatting',{u:0,i:0,b:0});
			$('td').not(':first-child')
					.on('click',enableEditing);
			initFormattingButtons();
			initTableEditing();
		}
	};
}());